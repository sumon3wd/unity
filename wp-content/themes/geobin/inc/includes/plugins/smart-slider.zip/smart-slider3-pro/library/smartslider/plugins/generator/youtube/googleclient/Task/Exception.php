<?php

namespace Nextend\GoogleApi;


class Google_Task_Exception extends Google_Exception {

}

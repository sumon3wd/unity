<?php if (!defined('FW')) die('Forbidden');

$manifest               = array();
$manifest['name']       = 'Smart Slider 3';
$manifest['version']    = '3.0.0';
$manifest['uri']        = 'https://smartslider3.com';
$manifest['author']     = 'Nextendweb';
$manifest['author_uri'] = 'https://smartslider3.com';
$manifest['standalone'] = true;
<?php

namespace Nextend\GoogleApi;

class Google_Exception extends \Exception {

}
